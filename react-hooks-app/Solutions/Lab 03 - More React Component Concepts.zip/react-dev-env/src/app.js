var scope = {
    title: "My React App",
    footerText: "footer text",
    color: "blue",
    message: "",
    selectedIndex: -1,
    author: { 
            name:"John Doe", 
            phone: "800-555-1212", 
            email: "jdoe@gmail.com" 
    }, 
    books: [
        {isbn:'123', title:'The Time Machine', price:5.95 },
        {isbn:'123', title:'War of the Worlds', price:6.95 },
        {isbn:'123', title:'The Invisible Man', price:4.95 }
    ]        
}

const divStyle = {
    backgroundColor: 'lightgrey',
    margin: '0px',
    padding: '5px', 
    textAlign: 'center',
};

function App(props){
    return (
    <div className={'boxed'}>
        <Header title={props.title}/>
        <Body {...props} />
        <Footer text={props.footerText} />
    </div> );
}

function Header(props){
    return <h3 style={divStyle} >{props.title}</h3>;
}

function Body(props){
    return ( <div>
        <p>Author:{props.author.name}</p>
        <BookList books={props.books} selected={props.selectedIndex} />
        <p>Enter your favorite color:</p>
        <input type='text' name='color' 
	onChange = {handleChange} 
	value={props.color} />
        <input type='button' value="Click Here" 
	onClick = {handleButtonClick} /> 
        <p>{props.message}</p>
     </div> );
}

function Footer(props){
    return ( <div>
	<h4 style={divStyle} >{props.text}</h4>
	</div> );
}

function BookList(props){
    return ( <ul>
        {props.books.map(
            (book, index) => {
                return ( <li 
                    onClick = {(e)=>handleListItemClick(e, index)}
                    className={ index === props.selected ? "selected" : ""}
                    key={index} >{book.title}</li> )}
        )}
    </ul>
    );
}

function handleChange(event){
    scope[event.currentTarget.name] = event.currentTarget.value;
    renderApp(scope);
}

function handleButtonClick(event){
    scope.message = "You like the color " + scope.color + "!";
    renderApp(scope);
 }

function handleListItemClick(event, index){
    scope.selectedIndex = index;
    const book = scope.books[index];
    renderApp(scope);
    console.log("You chose: " + book.isbn + ", " +
     book.title + ", " + book.price);
}

function renderApp(scope){
    ReactDOM.render( <App {...scope}/>,
        document.getElementById('react-container')
    );
}

renderApp(scope);