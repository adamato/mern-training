class myclass{
    constructor(name){this.name = name;}
    display(){console.log(this.name);}
  }
  new myclass("myclass").display();