ReactDOM.render(
    <h3>My App Title</h3>,
    document.getElementById('react-container'));