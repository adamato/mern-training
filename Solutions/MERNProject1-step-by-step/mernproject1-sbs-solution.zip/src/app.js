/* render title */
var title = "React Book List App";

/***** Render functions *****/
ReactDOM.render(
    <h3>{title}</h3>,
    document.getElementById('title')
);

var books = [{isbn:'000', title:'example title', price:0.00 }];
function renderBookList(list){
    // list items
    const listItems = list.map((item, index) =>
        <li key={index} 
          className={item.isbn === selectedIsbn ? "selected" : ""}
		  onClick={(e) => handleListClick(e, item.isbn)}
		>
            {item.isbn}, {item.title}, {item.price}
        </li>
    );

    // list component
    const listComponent = 
    <div>
        <h4>Book List</h4>
        <ul>{listItems}</ul>
        <input type={'button'} onClick={handleNewBookClick} value="New Book" />
    </div>

    // render component
    ReactDOM.render( listComponent, document.getElementById('book-list'));

}
function updateBookList() {
    // add fetch here
    fetch('./books', { mode: 'cors' })
        .then(function (response) {
            return response.text();
        })
        .then(function (text) {
            console.log('Request successful', text);
            books = JSON.parse(text);
            renderBookList(books);
        })
        .catch(function (error) {
            console.log('Request failed', error)
        });    
};

    // render Book Form
    var book = {isbn:'000', title:'example title', price:0.00 };
    function renderBookForm(book) {
        const bookForm = 
            <div>
                <h4>Book Form</h4>
                <form >
                    <table><tbody>
                        <tr>
                            <td>Isbn:</td>
                            <td><input type={'text'} name={'isbn'} onChange={handleChange} value={book.isbn} /></td>
                        </tr>
                        <tr>
                            <td>Title:</td>
                            <td><input type={'text'} name={'title'} onChange={handleChange} value={book.title} /></td>
                        </tr>
                        <tr>
                            <td>Price:</td>
                            <td><input type={'text'} name={'price'} onChange={handleChange} value={book.price} /></td>
                        </tr>
                    </tbody></table>
                    <input type={'button'} value="Save" onClick={ handleBookSaveClick } />
                    <input type={'button'} value="Delete" onClick={ handleBookDeleteClick } />
                </form>
            </div>

        ReactDOM.render(bookForm, document.getElementById('book-form'));
    }

    // handle save button click
    function handleBookSaveClick(e) {

        if (book != null && book.isbn != null && book.isbn.length > 0) {
            // send post request to update book
            let url = './books/' + book.isbn;
            let bodystring = JSON.stringify(book);

            // add fetch call for PUT here
            fetch(url, { method: 'PUT', headers: { "Content-Type": "application/json" }, body: bodystring }) 
                .then(function (data) {
                    // reload updated books list from service
                    updateBookList();   
                    // if new record was saved make it the selected book                 
                    if (selectedIsbn === null || ( selectedIsbn.length === 0 | selectedIsbn != book.isbn ) ) {
                        setSelectedBook(book.isbn);
                    }

                })
                .catch(function (error) {
                    console.log('Request failed', error);
                });
        } else {
            alert("isbn cannot be null for Save or Update!");
        }
    }
    // update book object when input field changes
    function handleChange(e){
        if(!book){ book = getBookByIsbn(selectedIsbn);}
        book[e.currentTarget.name] = e.currentTarget.value;
        renderBookForm(book);
    }

    // utility function to retrieve book from array
    function getBookByIsbn(isbn){
        for(let book of books){
            if(book.isbn === isbn){
                return book;
            }
        }
    }

// code to handle selected book
function handleListClick(event, isbn){
    event.preventDefault();
    setSelectedBook(isbn);    
    // alert(" item clicked: " + isbn);
}
var selectedIsbn = "";
function setSelectedBook(isbn){
    selectedIsbn = isbn;
    book = getBookByIsbn(isbn);
    renderBookList(books);
    renderBookForm(book);    
}

    // "New Book" button handler    
    function handleNewBookClick(){
        selectedIsbn = "";
        book = {isbn:"",title:"",price:""};
        renderBookList(books); // update to remove highlight if any
        renderBookForm(book);  // update form
    }

    // handle delete button click
    function handleBookDeleteClick(e) {
        if (book != null && book.isbn != null && book.isbn.length > 0) {
            // send post request to delete book
            let url = './books/' + book.isbn;
            fetch(url, { method: 'DELETE' })
                .then(function (data) {
                    console.log('Request succeeded with response: ', data);
                    // reload updated books list from service
                    updateBookList();
                    // reset selected book and re-render book form
                    book = { isbn: "", title: "", price: "" };
                    selectedIsbn = "";
                    renderBookForm(book);
                })
                .catch(function (error) {
                    console.log('Request failed', error);
                });
        } else {
            alert("isbn cannot be null for Delete!");
        }
    }
// call updateBookList() to initialize list
updateBookList();