import React, { Component } from 'react';
import './App.css';
import ApiTest from './components/ApiTest';

		class App extends Component {

		  render() {
			return (
			  <div className="App">
				<h3>React-Redux Book List App</h3>
				<ApiTest />
			  </div>
			);
		  }
		}

export default App;
