import React from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import Book from './Book'
import RestAPI from '../rest';
import { selectBook, updateFormUsage } from '../actions'


var doneInit = false;
const restapi = new RestAPI();

const BookList = ({ books, appState, onInit, 
                    onBookClick, handleNewBookClick }) => {
  onInit();
  return (  
  <div id='book-list' >
    <h4>Book List </h4>
      <ul>
        {books.map(book =>
          <Book
            key = {book.isbn}  
            book={book}
            selectedIsbn={ appState.selectedIsbn }  
            onClick={() => onBookClick(book)} 
          />
        )}
      </ul>
      <input type={'button'} onClick={handleNewBookClick} value="New Book" />
  </div>
)}

BookList.propTypes = {
  books: PropTypes.arrayOf(PropTypes.shape({
    isbn: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    price: PropTypes.string.isRequired
  }).isRequired).isRequired
}

const mapStateToProps = (state) => {
  const temp2 = state.appState;
  return {
    books: state.books,
    appState: temp2
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onInit: () => {
      console.log('in BookList.onInit:');
      if(!doneInit){
        restapi.getBooks(dispatch);
         doneInit = true;
      }
    },
		onBookClick: (book) => {
		  console.log('in BookList.onBookClick:' + JSON.stringify(book));
		  dispatch(selectBook(book));
      dispatch(updateFormUsage('view', book));
		},
    handleNewBookClick: () => {
      console.log('in BookList.handleNewBookClick:');
      dispatch(updateFormUsage('add'));
      dispatch(selectBook(-1));
    }        
  }
}

const VisibleBookList = connect(
  mapStateToProps,
  mapDispatchToProps
)(BookList)

export default VisibleBookList