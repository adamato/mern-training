import React from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import { updateFormObject } from '../actions'
import { updateFormUsage } from '../actions'
import { addBook, selectBook } from '../actions'
import RestAPI from '../rest';
import { deleteBook } from '../actions'
const restapi = new RestAPI();

const BookForm = ({ book, usage, handleChange, handleBookEditClick, 
                    handleEditCancelClick, handleBookSaveClick, 
                    handleBookDeleteClick }) => (
    <div id='book-form' >
        <div>
            <h4>Book Form {usage}</h4>
            <form >
                <table><tbody>
                    <tr>
                        <td>Isbn:</td>
                        <td><input type={'text'} name={'isbn'} onChange={handleChange} 
                             placeholder={'Unique ISBN #'}
                             value={book.isbn} disabled={usage==='none'||usage==='view'} /></td>
                    </tr>
                    <tr>
                        <td>Title:</td>
                        <td><input type={'text'} name={'title'} onChange={handleChange} 
                             placeholder={'Book title'}
                             value={book.title} disabled={usage==='none'||usage==='view'} /></td>
                    </tr>
                    <tr>
                        <td>Price:</td>
                        <td><input type={'number'} name={'price'} onChange={handleChange} 
                             placeholder={'Price'}
                             value={book.price} disabled={usage==='none'||usage==='view'} /></td>
                    </tr>
                </tbody></table>
                <input type={'button'} value="Delete" 
                    onClick={ (e)=>handleBookDeleteClick(e, book) } 
                    hidden={usage ==='none' || usage === 'view' || usage === 'add' } />
                <input type={'button'} value="Save" onClick={ (e)=>handleBookSaveClick(e, book) } hidden={ usage === 'none' || usage === 'view'} />
                <input type={'button'} value="Cancel" onClick={ (e)=>handleEditCancelClick(e, book) } hidden={ usage === 'none' || usage === 'view'} />
                <input type={'button'} value="Edit" onClick={ (e)=>handleBookEditClick(e, book) } hidden={ usage === 'none' || usage === 'edit' || usage === 'add'} />
            </form>
        </div>  
    </div>
)

BookForm.propTypes = {
  book:  PropTypes.shape({
    isbn: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    price: PropTypes.string.isRequired
  }).isRequired
}

const mapStateToProps = (state) => {
  return {
    book: state.formState.book,
    isbn: state.formState.book.isbn,
    usage: state.formState.usage,
    appState: state.appState
  }
}

const mapDispatchToProps = (dispatch) => {
  return { 
    handleChange: (e) => {
        const field_name = e.currentTarget.name;
        const field_value = e.currentTarget.value;
        dispatch( updateFormObject( field_name, field_value ));
    },
    handleBookEditClick: (event, book, usage) => {
        console.log("in BookForm.handleBookEditClick");
        dispatch( updateFormUsage('edit', book) );        
    },
    handleEditCancelClick: (event, book, usage) => {
        console.log("in BookForm.handleEditCancelClick");
        dispatch( updateFormUsage('view') );        
    },
    handleBookSaveClick: (event, book, usage) => {
        console.log("in BookForm.handleBookSaveClick");
        dispatch(addBook(book));
        if(usage === 'add'){
            dispatch(selectBook(book));
        }
        dispatch(updateFormUsage('none'));
        restapi.putBook(dispatch, book);
    },
    handleBookDeleteClick: (event, book) => {
        console.log("in BookForm.handleBookDeleteClick");
        console.log("book: " + JSON.stringify(book));
        dispatch(deleteBook(book));
        dispatch(updateFormUsage('none')); 
        restapi.deleteBook(dispatch, book);       
    }             
  }
}

const VisibleBookForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(BookForm)

export default VisibleBookForm