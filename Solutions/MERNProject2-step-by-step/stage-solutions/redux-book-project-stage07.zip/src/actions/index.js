export const applyBooksUpdate = (books) => {
  return {
    type: 'APPLY_BOOKS_UPDATE',
    books
  }
}

export const selectBook = (book) => {
  return {
  type: 'SELECT_BOOK',
  book
  }
}

export const addBook = (book) => {
  return {
  type: 'ADD_BOOK',
  book
  }
}

export const deleteBook = (book) => {
  return {
  type: 'DELETE_BOOK',
  book
  }
}

export const addBookInit = (book) => {
  return {
    type: 'ADD_BOOK_INIT',
    book
  }
}

export const updateFormObject = (field_name, field_value) => {
  return {
  type: 'UPDATE_FORM_OBJECT',
  field_name:field_name,
  field_value:field_value
  }
}

// accepted values for usage: 'view', 'add', 'update'
export const updateFormUsage = (usage, book) => {
  return {
    type: 'UPDATE_FORM_USAGE',
    usage: usage,
    book: book
  }
}