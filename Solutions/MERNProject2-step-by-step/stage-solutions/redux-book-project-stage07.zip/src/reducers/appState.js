const initial = {selectedIsbn:"9876", selectedBook:{} };

const appState = (state = initial, action, data) => {

    switch (action.type) {
    case 'SELECT_BOOK': {
        let book_copy = Object.assign({}, action.book);
        return Object.assign({}, {selectedIsbn: action.book.isbn}, {selectedBook: book_copy });
    }    

    default:
        return state
    }
}

export default appState