import React from 'react'
import PropTypes from 'prop-types'

const Book = ({ onClick, selectedIsbn, book }) => {
  return (
    <li>
        {book.isbn}, {book.title}, {book.price}
    </li>
  );
}

Book.propTypes = {
  book: PropTypes.object.isRequired
}

export default Book