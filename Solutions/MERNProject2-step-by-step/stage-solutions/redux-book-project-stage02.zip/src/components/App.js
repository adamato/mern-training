import React, { Component } from 'react';
import './App.css';
import ApiTest from './ApiTest';
import BookList from './BookList';

		class App extends Component {

		  render() {
			return (
			  <div className="App">
				<h3>React-Redux Book List App</h3>
				{/* <ApiTest /> */}
				<BookList />
			  </div>
			);
		  }
		}

export default App;
