export const applyBooksUpdate = (books) => {
  return {
    type: 'APPLY_BOOKS_UPDATE',
    books
  }
}