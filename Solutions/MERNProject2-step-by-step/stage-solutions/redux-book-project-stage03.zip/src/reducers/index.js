import { combineReducers } from 'redux'
import books from './books'

const bookApp = combineReducers({books:books})

export default bookApp