export const applyBooksUpdate = (books) => {
  return {
    type: 'APPLY_BOOKS_UPDATE',
    books
  }
}

export const selectBook = (book) => {
  return {
  type: 'SELECT_BOOK',
  book
  }
}

export const updateFormObject = (field_name, field_value) => {
  return {
  type: 'UPDATE_FORM_OBJECT',
  field_name:field_name,
  field_value:field_value
  }
}

// accepted values for usage: 'view', 'add', 'update'
export const updateFormUsage = (usage, book) => {
  return {
    type: 'UPDATE_FORM_USAGE',
    usage: usage,
    book: book
  }
}