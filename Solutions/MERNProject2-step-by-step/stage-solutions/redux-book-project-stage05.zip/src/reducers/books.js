const initial = [
    {isbn:"1328",title:"Moby Dick", price: "23" },
    {isbn:"1001",title:"The Odyssey", price: "18" },
    {isbn:"1013",title:"Great Expectations", price: "12" }
    ];

const books = (state = initial, action, data) => {
    switch (action.type) {

    case 'APPLY_BOOKS_UPDATE':{  
        console.log("in reducer books.APPLY_BOOKS_UPDATE");
        let newstate = [...action.books]; 
        return newstate;
    }

    default:
        console.log("in reducer books.default");
        return state
    }
}

export default books