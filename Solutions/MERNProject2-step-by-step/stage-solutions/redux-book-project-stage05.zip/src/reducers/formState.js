const initial = {usage: 'view', book:{isbn:"",title:"", price: "" }};

const formState = (state = initial, action, data) => {

    switch (action.type) {
    case 'UPDATE_FORM_OBJECT': {
        let field = {};
        field[action.field_name] = action.field_value;
        let book = Object.assign({}, state.book, field);
        const obj = Object.assign({}, state, {book:book} );
        return obj;
    }  

    case 'UPDATE_FORM_USAGE': {
      let usage = {usage: action.usage };
      let new_book = {};
      
      if(action.usage === 'view'){
        new_book = {book: Object.assign({}, action.book)};
      } 

      return Object.assign({}, state, new_book, usage);
    }
    
    default:
        return state
    }
}

export default formState