import React from 'react'
import PropTypes from 'prop-types'

const Book = ({ onClick, selectedIsbn, book }) => {
  return (
    <li className={book.isbn === selectedIsbn ? "selected" : ""}
		    onClick={(e) => onClick(e, book.isbn)} >
        {book.isbn}, {book.title}, {book.price}
    </li>
  );
}

Book.propTypes = {
  onClick: PropTypes.func.isRequired,
  selectedIsbn: PropTypes.string,
  book: PropTypes.object.isRequired
}

export default Book