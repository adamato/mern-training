import { applyBooksUpdate } from '../actions'
 
class RestAPI {

  getBooks( dispatch ) {
    let myHeaders = new Headers({ "Content-Type": "application/json" });
    var myInit = { method: 'GET', headers: myHeaders, mode: 'cors' };
    let promise = fetch("/books", myInit);
    promise.then((response) => {
      return response.text();
    }).then(function (text) {
      console.log('Request successful: ', text);
      let books = JSON.parse(text);
      dispatch(applyBooksUpdate(books));
    });
  }

	putBook( dispatch, book ) {
		let url = "/books/" + book.isbn;
		let myHeaders = new Headers({ "Content-Type": "application/json" });
		let body = JSON.stringify(book);
		var myInit = { 
		  method: 'PUT',
		  body: body, 
		  headers: myHeaders, 
		  mode: 'cors' 
		};
		let getbooks = this.getBooks;
		let promise = fetch(url, myInit);
		promise.then((response) => {
		  return response.text();
		}).then(function (text) {
		  console.log('put request completed: ', text);
		  getbooks(dispatch);
		});
	}

}

export default RestAPI;