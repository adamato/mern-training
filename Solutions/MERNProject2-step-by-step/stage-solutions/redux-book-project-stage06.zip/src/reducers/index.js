import { combineReducers } from 'redux'
import books from './books'
import appState from './appState'
import formState from './formState'

const bookApp = combineReducers({formState:formState,appState:appState,books:books})

export default bookApp