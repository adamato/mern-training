import { combineReducers } from 'redux'
import books from './books'
import appState from './appState'

const bookApp = combineReducers({appState:appState,books:books})

export default bookApp