export const applyBooksUpdate = (books) => {
  return {
    type: 'APPLY_BOOKS_UPDATE',
    books
  }
}

export const selectBook = (book) => {
  return {
  type: 'SELECT_BOOK',
  book
  }
}