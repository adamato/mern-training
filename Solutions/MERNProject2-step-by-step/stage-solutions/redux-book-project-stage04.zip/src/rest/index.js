import { applyBooksUpdate } from '../actions'
 
class RestAPI {

  getBooks( dispatch ) {
    let myHeaders = new Headers({ "Content-Type": "application/json" });
    var myInit = { method: 'GET', headers: myHeaders, mode: 'cors' };
    let promise = fetch("/books", myInit);
    promise.then((response) => {
      return response.text();
    }).then(function (text) {
      console.log('Request successful: ', text);
      let books = JSON.parse(text);
      dispatch(applyBooksUpdate(books));
    });
  }
  
}

export default RestAPI;