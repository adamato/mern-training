const initial = {usage: 'none', book:{isbn:"",title:"", price: "" }};

const formState = (state = initial, action) => {

    switch (action.type) {

    case 'UPDATE_FORM_FIELD': {
        let field = {};
        field[action.field_name] = action.field_value;
        let book = Object.assign({}, state.book, field);
        const obj = Object.assign({}, state, {book:book} );
        return obj;
    }  


    case 'UPDATE_FORM_OBJECT': {
        let new_book = {book: Object.assign({}, action.book)};
        return Object.assign({}, state, new_book );
    }


    case 'UPDATE_FORM_TO_NEW': {
        let isbn = Math.floor(1000 * (1 + Math.random(Date.now()))).toString();
        let new_book = {book:{isbn: isbn,title:"", price: "0.00" }};
        console.log("UPDATE_FORM_TO_NEW: new_book: " + JSON.stringify(new_book));
        return Object.assign({}, state, new_book);
    }

    case 'UPDATE_FORM_TO_NONE': {
        return Object.assign({}, initial);
    }

    case 'UPDATE_FORM_USAGE': {
      let usage = {usage: action.usage };
      console.log("UPDATE_FORM_USAGE: (" + action.usage );
      return Object.assign({}, state, usage);
    }
    
    default:
        return state
    }
}

export default formState