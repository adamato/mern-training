const initial = {selectedIsbn:"123"};

const appState = (state = initial, action ) => {

    switch (action.type) {
    case 'SELECT_BOOK': {
        return {selectedIsbn: action.book.isbn };
    }    

    default:
        return state
    }
}

export default appState