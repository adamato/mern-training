import React from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import RestAPI from '../rest/'
import { addBook, updateFormField, updateFormUsage, 
         selectBook, deleteBook, updateFormToNone } from '../actions'

const restapi = new RestAPI();

const BookForm = ({ book, usage, handleChange, handleBookEditClick, 
                    handleBookCancelClick, handleBookSaveClick, 
                    handleBookDeleteClick }) => {
  return (
  <div id='book-form' >
    <h4>Book Form {usage}</h4>
        <form >
            <table><tbody>
                <tr>
                    <td>Isbn:</td>
                    <td><input type={'text'} name={'isbn'} onChange={handleChange} 
                        disabled={usage==='none'||usage==='view'}
                        value={book.isbn}  /></td>
                </tr>
                <tr>
                    <td>Title:</td>
                    <td><input type={'text'} name={'title'} onChange={handleChange} 
                        disabled={usage==='none'||usage==='view'}
                        value={book.title}  /></td>
                </tr>
                <tr>
                    <td>Price:</td>
                    <td><input type={'number'} name={'price'} onChange={handleChange} 
                        disabled={usage==='none'||usage==='view'}
                        value={book.price}  /></td>
                </tr>
            </tbody></table>
                <input type={'button'} value="Delete" 
                    onClick={ (e)=>handleBookDeleteClick(e, book) } 
                    hidden={usage ==='none' || usage === 'view' || usage === 'add' } />            
            <input type={'button'} value="Edit" onClick={ (e)=>handleBookEditClick(e, book) } hidden={usage !=='view'} />
            <input type={'button'} value="Cancel" onClick={ (e)=>handleBookCancelClick(e, usage ) } hidden={usage ==='view' || usage === 'none'} />
            <input type={'button'} value="Save" onClick={ (e)=>handleBookSaveClick(e, book, usage) } hidden={usage ==='view' || usage === 'none'} />
        </form>
  </div>
)}

BookForm.propTypes = {
}

const mapStateToProps = (state) => {
  return {
    book: state.formState.book,
    usage: state.formState.usage
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    handleChange: (event) => {
      console.log('in BookForm.handleChange:');
      let name = event.currentTarget.name;
      let value = event.currentTarget.value;
      dispatch(updateFormField(name,value));

    },
    handleBookEditClick: () => {
        console.log("in BookForm.handleBookEditClick");
        dispatch( updateFormUsage('edit') );        

    },
    handleBookCancelClick: (event, usage) => {
        console.log("in BookForm.handleBookCancelClick");
        if( usage === 'add'){
            dispatch( updateFormToNone() );
        }        
        dispatch( updateFormUsage('view') );        

    },
    handleBookSaveClick: (event, book, usage) => {  
        console.log("in BookForm.handleBookSaveClick");
        dispatch(addBook(book));
        if( usage === 'add'){
            dispatch( selectBook(book) );
        }
        dispatch(updateFormUsage('view'));
        restapi.putBook(dispatch, book);

    }, handleBookDeleteClick:(event, book) => {
        console.log("in BookForm.handleBookDeleteClick");
        console.log("book: " + JSON.stringify(book));
        dispatch(deleteBook(book));
        dispatch(updateFormToNone()); 
        restapi.deleteBook(dispatch, book);       
    }

  }
}

const VisibleBookForm = connect(
  mapStateToProps,
  mapDispatchToProps
)(BookForm)

export default VisibleBookForm