import React from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import RestAPI from '../rest'
import { selectBook, updateFormUsage, updateFormObject, updateFormToNew } from '../actions'

const restapi = new RestAPI();
var doneInit = false;

const BookList = ({ books, selectedIsbn, onInit, onClick, handleNewBookClick }) => {
  onInit();
  return (
  <div id='book-list' >
    <h4>Book List</h4>
      <ul>
        { books.map( book => <li 
            key={book.isbn} 
            className={book.isbn === selectedIsbn ? "selected" : ""} 
            onClick={(e) => onClick(book)}
        >{book.isbn},{book.title},{book.price} </li>) }
      </ul>
      <input type={'button'} onClick={handleNewBookClick} value="New Book" />
  </div>
)}

BookList.propTypes = {
  selectedIsbn: PropTypes.string
}

const mapStateToProps = (state) => {
  return {
    books: state.books,
    selectedIsbn: state.appState.selectedIsbn
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onInit: () => {
      console.log('in BookList.onInit:');
      if(!doneInit){
        restapi.getBooks(dispatch);
        doneInit = true;
      }
    },
    onClick: (book) => {
      let action = selectBook(book);
      dispatch(action);
      dispatch( updateFormUsage( 'view' ) );
      dispatch( updateFormObject( book ) );
    },
    handleNewBookClick: () => {
      console.log('in BookList.handleNewBookClick:');
      dispatch(updateFormToNew());
      dispatch(updateFormUsage('add'));
      dispatch(selectBook(-1));
    }
  }
}

const VisibleComponent = connect(
  mapStateToProps,
  mapDispatchToProps
)(BookList)

export default VisibleComponent