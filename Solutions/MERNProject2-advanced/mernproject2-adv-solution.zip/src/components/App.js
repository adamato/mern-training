import React, { Component } from 'react';
import './App.css';
import BookList from './BookList'
import BookForm from './BookForm'

class App extends Component {
  render() {
    return (
      <div className="App">
        <h3>MERN Project2 - React/Redux App</h3>
          <BookList />
          <BookForm />
      </div>
    );
  }
}

export default App;
