export const applyBooksUpdate = (books) => {
  return {
    type: 'APPLY_BOOKS_UPDATE',
    books
  }
}

export const selectBook = (book) => {
  return {
  type: 'SELECT_BOOK',
  book
  }
}

export const updateFormObject = ( book ) => {
  return {
  type: 'UPDATE_FORM_OBJECT',
  book: book
  }
}

export const updateFormUsage = (usage) => {
  return {
    type: 'UPDATE_FORM_USAGE',
    usage: usage
  }
}

export const updateFormField = (field_name, field_value) => {
  return {
  type: 'UPDATE_FORM_FIELD',
  field_name:field_name,
  field_value:field_value
  }
}

export const addBook = (book) => {
  return {
  type: 'ADD_BOOK',
  book
  }
}

export const updateFormToNew = ( book ) => {
  return {
  type: 'UPDATE_FORM_TO_NEW',
  book: book
  }
}

export const updateFormToNone = () => {
  return {
  type: 'UPDATE_FORM_TO_NONE'
  }
}

export const deleteBook = (book) => {
  return {
  type: 'DELETE_BOOK',
  book
  }
}